# Changelog

Visit [releases](https://github.com/codesoclock/alfapay/releases) for full changelog.
